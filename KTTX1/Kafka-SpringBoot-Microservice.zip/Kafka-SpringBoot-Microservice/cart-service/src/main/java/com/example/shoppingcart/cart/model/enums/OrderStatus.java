package com.example.shoppingcart.cart.model.enums;

public enum OrderStatus {
    CREATED,
    PROCESSING,
    COMPLETED,
    CANCELLED
}
