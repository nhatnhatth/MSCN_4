package com.example.shoppingcart.payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentEntityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
